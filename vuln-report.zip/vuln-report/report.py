import os

def print_header(title):
    print("\033[1;34m[+] " + title + "\033[0m")

def print_info(msg):
    print("\033[1;36m[i] " + msg + "\033[0m")

def print_warning(msg):
    print("\033[1;33m[!] " + msg + "\033[0m")

def print_critical(msg):
    print("\033[1;31m[!!] " + msg + "\033[0m")

def print_success(msg):
    print("\033[1;32m[✓] " + msg + "\033[0m")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def generate_report():
    clear_screen()

    print_header("=== Vulnerability Report for c-exchange.com ===\n")

    print_header("🔹 Target Overview")
    print_info("Domain Info:")
    print_info("  Registered On: 2020-09-10")
    print_info("  Expires On: 2028-09-10")
    print_info("  Updated On: 2025-07-25")
    print_info("  Likely Registered On: Namecheap.com")
    print_info("IP Address: 161.97.122.171")
    print_info("Platform: Exchangerix-based Crypto Exchange")
    print_info("Open Ports: 21, 53, 80, 110, 143, 443, 587, 3306")
    print_info("Services Detected: FTP, HTTPS, SMTP, MariaDB, PowerDNS")
    print_info("Description: Exposed ports like 21 (FTP) and 3306 (MariaDB) are risky if accessible externally, as they may allow unauthorized access to file systems or databases. Ports 80 (HTTP) and 443 (HTTPS) are expected for web services, but others (e.g., 110, 143) suggest additional services that could be exploited if misconfigured.")
    print_info("Solution: Restrict unnecessary ports (e.g., 21, 3306) to authorized IPs only. Use a firewall to limit access to sensitive services like MariaDB and FTP.")

    print_header("🔸 Subdomains Discovered (Top 10)")
    subdomains = [
        "admin.c-exchange.com",
        "blog.c-exchange.com",
        "chat.c-exchange.com",
        "data.c-exchange.com",
        "demo.c-exchange.com",
        "escrow.c-exchange.com",
        "shop.c-exchange.com",
        "test.c-exchange.com",
        "trade.c-exchange.com",
        "webmail.c-exchange.com"
    ]
    for sub in subdomains:
        print("   - " + sub)
    print_info("Description: Exposed subdomains, especially admin, test, and webmail, may reveal sensitive interfaces or outdated systems. Attackers can target these for brute-force attacks, misconfigurations, or unauthorized access.")
    print_info("Solution: Disable or restrict access to non-essential subdomains (e.g., test, demo). Implement access controls and monitor for unauthorized activity.")

    print_header("🔸 Exposed Paths (Top 7)")
    paths = [
        "/.git/HEAD (403)",
        "/controlpanel (200)",
        "/cpanel (200)",
        "/webmail (200)",
        "/uploads (301)",
        "/robots.txt (200)",
        "/sitemap.xml (200)"
    ]
    for path in paths:
        print("   - " + path)
    print_info("Description: Exposed paths like /.git/ may leak source code or configuration details. Accessible admin interfaces (/controlpanel, /cpanel) and /webmail without authentication are prime targets for attackers. The /uploads directory could allow unauthorized file access or uploads if not secured.")
    print_info("Solution: Block access to sensitive paths (e.g., /.git/, /controlpanel) via web server configuration. Restrict /webmail and /uploads to authenticated users only.")

    print_header("🔸 ZAP Scan Findings")

    print_critical("High - Absence of Anti-CSRF Tokens")
    print("   Count: 272")
    print("   Description: Forms lack Cross-Site Request Forgery (CSRF) tokens, allowing attackers to trick authenticated users into performing unintended actions (e.g., transferring funds) by submitting malicious requests via phishing or malicious sites.")
    print_info("Solution: Implement CSRF tokens in all forms. Use frameworks like Django or Flask with built-in CSRF protection. Validate tokens server-side.")

    print_warning("Medium - Missing Security Headers")
    print("   Issues:")
    print("     - CSP Header Not Set (210)")
    print("     - X-Frame-Options Missing (202)")
    print("     - X-Content-Type-Options Missing (465)")
    print("     - Strict-Transport-Security Not Set (569)")
    print("   Description: Missing Content-Security-Policy (CSP) allows unsafe scripts or resources, increasing XSS risks. No X-Frame-Options enables clickjacking attacks. Missing X-Content-Type-Options can lead to MIME-type sniffing exploits. Absence of Strict-Transport-Security (HSTS) risks man-in-the-middle attacks on HTTP connections.")
    print_info("Solution: Add security headers: Content-Security-Policy (CSP), X-Frame-Options: DENY, X-Content-Type-Options: nosniff, and Strict-Transport-Security (HSTS) with max-age=31536000.")

    print_warning("Medium - Cookie Security Issues")
    print("   Issues:")
    print("     - No HttpOnly Flag (2)")
    print("     - No SameSite Attribute (2)")
    print("   Description: Cookies without HttpOnly are accessible to JavaScript, risking theft via XSS. Missing SameSite attributes allow cookies to be sent in cross-site requests, enabling CSRF attacks. These issues expose session tokens to unauthorized access.")
    print_info("Solution: Set HttpOnly and SameSite=Strict/Lax attributes on cookies. Ensure Secure flag is set for HTTPS-only transmission.")

    print_warning("Medium - Cross-Domain JavaScript Inclusion")
    print("   Count: 692")
    print("   Description: Loading JavaScript from external domains can introduce malicious scripts or outdated libraries, leading to XSS or data theft if the external source is compromised or untrusted.")
    print_info("Solution: Host JS files locally or use Subresource Integrity (SRI) for external scripts. Implement a strict CSP to limit script sources.")

    print_warning("Medium - Sensitive Info in URLs")
    print("   Count: 217")
    print("   Description: Session tokens or sensitive data in URLs (e.g., query parameters) can be exposed in browser history, server logs, or Referer headers, making them accessible to attackers via phishing or misconfigured servers.")
    print_info("Solution: Avoid passing sensitive data in URLs. Use POST requests for sensitive data and store session tokens in secure cookies.")

    print_warning("Medium - Retrieved from Cache")
    print("   Count: 23")
    print("   Description: Sensitive pages cached by browsers or proxies may expose user data (e.g., session tokens, personal info) to unauthorized users accessing the same device or network.")
    print_info("Solution: Set Cache-Control: no-store, no-cache for sensitive pages. Use Pragma: no-cache and Expires: 0 headers.")

    print_warning("Medium - Cross-Domain Misconfiguration")
    print("   Count: 14")
    print("   Description: Improper Cross-Origin Resource Sharing (CORS) policies or domain settings may allow unauthorized domains to access sensitive resources, leading to data leakage or unauthorized API access.")
    print_info("Solution: Configure strict CORS policies, allowing only trusted origins. Validate and sanitize cross-domain requests server-side.")

    print_warning("Medium - Big Redirect Detected")
    print("   Count: 1")
    print("   Description: Large or improperly configured redirects may leak sensitive data (e.g., tokens) via Referer headers or expose users to phishing by redirecting to untrusted sites.")
    print_info("Solution: Review and minimize redirects. Ensure redirects do not expose sensitive data in Referer headers. Use relative URLs where possible.")

    print_warning("Medium - User Controllable HTML Attribute")
    print("   Count: 10")
    print("   Description: User inputs reflected in HTML attributes (e.g., input fields, href) without proper sanitization can lead to Cross-Site Scripting (XSS) attacks, allowing attackers to inject malicious scripts.")
    print_info("Solution: Sanitize and encode all user inputs. Use a library like DOMPurify to prevent XSS. Implement a strict CSP.")

    print_header("✅ Summary")
    print("   - Critical CSRF issues found")
    print("   - Widespread missing security headers")
    print("   - Cookie misconfigurations")
    print("   - External JS inclusion risks")
    print("   - Sensitive data leakage vectors")
    print_info("Solution: Prioritize CSRF protection, implement security headers, secure cookies, host JS locally, and sanitize user inputs to mitigate risks.")

generate_report()
