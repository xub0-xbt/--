import hangman
hangman.main()