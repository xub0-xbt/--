import os
import sys
import hangman

if os.name == 'nt':
    os.system('cls')
else: 
    os.system('clear')

hangman.main()